#!/bin/sh -e
# ESET Security Management Center
# Copyright (c) 1992-2020 ESET, spol. s r.o. All Rights Reserved

cleanup_file="$(mktemp -q)"
finalize()
{
  set +e
  if test -f "$cleanup_file"
  then
    while read f
    do
      rm -f "$f"
    done < "$cleanup_file"
    rm -f "$cleanup_file"
  fi
}

trap 'finalize' HUP INT QUIT TERM EXIT

eraa_server_hostname="ACONESETV6.ACONHOSTING.local"
eraa_server_port="2222"
eraa_server_company_name=""
eraa_peer_cert_b64="MIIKWgIBAzCCChYGCSqGSIb3DQEHAaCCCgcEggoDMIIJ/zCCBhgGCSqGSIb3DQEHAaCCBgkEggYFMIIGATCCBf0GCyqGSIb3DQEMCgECoIIE/jCCBPowHAYKKoZIhvcNAQwBAzAOBAg+StmX82GCvAICB9AEggTY/W8NgvbZUCXmCPfgn0sv+IQMUWIfg6Zv3hCsR8sw85+Ziw7LE0kMy7Ks6MQgEJkMcUHOUnU99KOf4az7NjmoUQYgMeMZEjTEvL0fQKHZewsara132kmfm+2BGwfA+1DlGfNjCl8Prh4oOnl+PaAR8wZk0unajVVcJd1hstzXpCA6Wc0Unowd1of7q4Ov4g9ynvU/pVF/YHSZmU2uQIMp5Sa9P9hj6SulWebToTy6wIDuxSaH5Afchb4I4uerhm8GFKy5L3Icxyq4tiNj3/yYsA5ogKlOPoGTf3iyru6scNnvz45YHzti4AQWv/OjQninvsh0U75cNFKsax3CifYmO0nmysDdlpZZ9ncjvzWj1+IDyGhV4tXrJvrRXRK0U1QDzTX2bBDT+QtAFF3GsofvEFgwMhvrqvF3m8EG0aoQf7SUG8tbRSIBi5dE2smv5PVvcSc7DQYmEILP8R3ychN8e8XiKVtLqGxoLV7VIMnxFApfRg54gPyiFzT+N0v/I7LIQTxoGUOfajx992GjgUwZZGltlMkk1HxCwkoDqwXS8tKC0kBNpQf6+zv1Hc2V/uwCyOuo+vZOKQd/V1zG9B0Hg1D+SMqkR55Mw6k2K4GC2VxjcPNuYLi1O0CIyQAZeblHrvqwLK9r7RsadVHCzSbcdhUPyHcW0KEqF97BGzjaDZ4ivQl6jynpqq2YPk+gKaGuvRxfPbI5AyEKk3Y8SwSxPmLilJda2UFGsT3/4CSuA6vaSN08Dbbpf0NEWpfhzv7/ggD4rpE0QUdhaN0LXuMREt0fOvFkdld615LeS5eMoELZJ5faNLKW+pKX+05poNOjtZbIuG3saGjpjzI41U5R2kEDhyIGkvM5U4aXPtDq/i58yTdRb1NX9anCvbzMALKLg6cDy4MEX3gakIs+5kg+EO+1+O6IZhwVGCxrGhhdXs1zanVOrFJCVolrM3FyefFC93Uk1cWZ9aLHH+CzuvNJ65SRjKOYf8LuiAY4wUeAkjl6bSX1Pz0uOruxzCgcTP/Hu5gwOusZWlDJnKTw0cHEhbYie+UMa5jhLwIsw5MzHKuc7szTSgx9yaPeAnBeRotJpwfgNFB5G+qrRSNXZgGr77Fwk02DWnDso7qiJgozfYt4IcFgDlZv5s2xbSBvjiGQZQxTI8ymCspQYQUaNR5j53PjElp6qQFe98/YLlaN/Nb0tmERGVwCBOiu/elhlztFxFCeNQc5glPANuwRSRrnNBwUOnvfahPqxXv5zlGGkxW/ZdeoJYMgGXJ1Lu5fAMABZB9nyy64xKC0ioH7i1R6/EQJXRKLva3gb7W1z52ge5fatT32Pp77Eh8snFGZjqGdltHiC9r7PgGgqqIcn4Rsq5l5NpHeLY0YHHlGuvR6HEBUZK0Is5ve9D0M9Qb9J4Qww0wcM9GD/sK9ppyNlqH8lJVOj+bix2n32Czdt3AZ5dN/ZEjcCVCCS6AsqbLMXz1OWnqvboO8QsjEyr0ZGjitmWtiOsfuXRmaOXU8+6mkRBHl4VxJQX1+ZYAemvWUnttCx1aML9eGqbU1qU3aNlpaN1wZtBRKYe/MmNCIslOK8RYuIv+WCigDqG4SM+PJ/bkctuwoP/+UuaxkRM48cUU4aBRwziYAkwq2yfESCpTKwQEcOUwPl299FjGB6zATBgkqhkiG9w0BCRUxBgQEAQAAADBnBgkqhkiG9w0BCRQxWh5YAEUAUwBFAFQALQBSAEEALQA2AGQAZgAwAGYAZAA1AGQALQA5ADEAMwBkAC0ANABjADQAOQAtAGIAMwBmADgALQBmAGIAYwBiADEANwA1ADQANgBkADAAMDBrBgkrBgEEAYI3EQExXh5cAE0AaQBjAHIAbwBzAG8AZgB0ACAARQBuAGgAYQBuAGMAZQBkACAAQwByAHkAcAB0AG8AZwByAGEAcABoAGkAYwAgAFAAcgBvAHYAaQBkAGUAcgAgAHYAMQAuADAwggPfBgkqhkiG9w0BBwagggPQMIIDzAIBADCCA8UGCSqGSIb3DQEHATAcBgoqhkiG9w0BDAEGMA4ECHkWw8IWjqRkAgIH0ICCA5jlBjDY9JPh4ZV/deXhtbPaP2w7am8v9B7aNy7O6HAN95I105NLeMi3/d9Wp5zfZMlYvzIkH380QjQZFh4VjFM88gD5MDjxBGgWbsJjoOIDennnSpXimcGKJMozvLQ+025Bhh0UwsS1rDtARQeNJfNa9mvWBJR4DxMxZEnBRKxnjXg43kXCdGu4m0SkJpu7PrhzJr5DiHHvdE4ibl86uJeyQQKbyJWDdokIjrFSYZzDiOeMscTFY6kM7X9z9k8QabSgJrI1KYdps40J/5CVUme6++5UnlShkvvIdKYv4sKPwJqLLRiP2ct4SqoRyfwyCsB3f9WMSUWPMVZgc4IwCB89ojEh2bJ+/D4xmCoK+sd93uYwXqJgwDctMYQMSiTfAxAo8liijK+t4PLRWDv3hT2usUMJJ6h0OVwFv8IpNUPGPM1Q4P58aQ74sE7CxWkeCaFf1cYFh0aOg7KIoWhkEvJDv0xegyAu1r3Ndf07l/m1FlDeOXSuVFUFQ+mE3NLEURTkoHG4fr0dXNxs9E/eTEy2kgdhPX3gV4SPVbz0x/Mnt3L6E2LHFkPH3bkGXXc5HHWJug5aFkiK3JwcR477o63bUXmfHhzXZnUL/jkZYMCMo2Vr1LnijLmTt17Zq2QliGnsWNPYXs48e9K3G2SX6IwWpnOz+YugUaOozI9ToS9emSJ4yrImQd6d0wnFKJAtcGyN4vG8Vt5+xKy36nBX5UTm7ZyBxY/9t1TcAkJvKYQMihV6Tut1VAz9yqDqeNuw3XCP3c7AWzg2bGW4eQ6swboMjq+vyeZg1vXA8uUowPgrl3ms/BvLUwkXgo+F8irVzJZKITVGxzaavUpLBKRqj6rb5JDflW9L7nnm16kS+wLoXxpdSwpweSemI2sE5qbjLwQt48cHAXpUkTYxxPJ7W7IlV+VxHjqqGEDK0uf94nF2YFvOERbT72Nyg/h9kTKeYy7OmOzWtg2a+Y/cKFrCbZy/ChhXdL3TuEtzYbPyMzOuWAw4PJ/rQoc4ioPyCKFGqBfPLitXiXXtJcFbbCFs1I/VDRYXaMr2xtUEsRdX7B5rnRoD+hTOaS2vuj1EqI0/g95jF+przW5hKCuq195L/IXkqPyWrHQYcVOP5UYWuKNpuYHe5tOMHo4cmxuefdkDrGMUaFeW6cHlpW8kVyOrgotpdJVgkOrjz4UJOvVmbv3TK5smVZwet8kf0MFdqyWBWms37WVZ8Dr/xDA7MB8wBwYFKw4DAhoEFDkaikHo+i3MsZb+oVhrZMiq4Zo0BBTGpsKnuJjYg6x6I50IQD2v8/29zgICB9A="
eraa_peer_cert_pwd=""
eraa_ca_cert_b64="MIIDITCCAgmgAwIBAgIQUsoXTJWZo5JFdpakKZa+IDANBgkqhkiG9w0BAQUFADApMScwJQYDVQQDEx5TZXJ2ZXIgQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkwHhcNMTYwMjAxMDAwMDAwWhcNMjYwMjAyMDAwMDAwWjApMScwJQYDVQQDEx5TZXJ2ZXIgQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCnUUx4QgTsdCQ5AFkMlMp3VwIvTuLABpDSgbalJAcHaJ9ejs/HbVxBdpuUDJ6bGjCKbCYAGO7GA5um5W5i1qeBY2YWsdnuj22yGdUhYY5ktNjXR8Abml7C7vPXZgY5A4zY1q/Lb/u5gvy7ZNrIZh+uDQQaHvOIxhp6869FnzVApRpUD3/FB5wW0Q/QcXoMdhQ1XrkoaspEkBnxf/XJUnn/62LBZjHKhhna1sTmo3SYcdss5c3+Hxs1TBOuiaLt+nRgUZP7NjL4VpL4EKhZcj7g9806fkPV1C+X0E8dCxAJSMl3p7MFbViylh8cjGu2VWJaiE66GuouGC/cuCI8NVGdAgMBAAGjRTBDMA4GA1UdDwEB/wQEAwIBBjASBgNVHRMBAf8ECDAGAQH/AgEAMB0GA1UdDgQWBBSgqdYrvcStLNvSHv176X7jYw5YzjANBgkqhkiG9w0BAQUFAAOCAQEAC7v35OQ8lrncclH8k9h8LZoWOBczhQfOS2inOr+OB/TbhjBLT8T2+VIhqZQ4RU0CainYd8dduyErKILDKi58wqGRSEXqwfFwXYaRBxjaT5W/9Z7e9ZqRzEFj6oeJVbNLYgype8SDWa23slH8wF3X29FjM6HJDbF7dNPpt6GoAwyfbEPo0fSIeNNCvDpgP179smFvrXduinIe7qer2mxkkR/OdQ7ndg88kEZ1AZILje0CzXLgpbXbHbb56Nh8I+hfBo+EbVnypGBsWFhU4OtV2rpzOPSia/BG5Vr6p/GXJxkxGZ3h0xqHE4FQcK9VjtXj3NGV+fIr7eGs94ST1aoA/w=="
eraa_product_uuid=""
eraa_initial_sg_token="MmVmZGVjYmMtMGIzZC00NjkyLWJmNDItOTNjMDYwZmE2NTM4L0OxeD4qS5ewNOzFt+utBwlgGK45fEIKhOLUAKG/fWv4KQ/Y6sXDqCv/ripTGQcKfD9YGA=="
eraa_policy_data="eyJwb2xpY3kiOnsiZm9ybWF0IjoiMSIsInZlcnNpb25fbWFqb3IiOiI0Mjk0OTY3Mjk1IiwidmVyc2lvbl9taW5vciI6IjQyOTQ5NjcyOTUiLCJ2ZXJzaW9uX2J1aWxkIjoiNDI5NDk2NzI5NSIsImRhdGEiOnsiZXJhIjp7ImFnZW50Ijp7ImNlX2ZsYWdzIjoiMCIsImF1dG9tYXRpb24iOnsiY2VfZmxhZ3MiOiIwIiwicmVwbGljYXRpb25fdHJpZ2dlciI6eyJjZV9mbGFncyI6IjQiLCJjcm9uX2ludGVydmFsIjp7ImNlX2ZsYWdzIjoiNCIsImNlX3R5cGUiOiIxIiwiY2VfdmFsdWUiOiJSIFIvMSAqICogKiA/ICoifSwiZGVsYXkiOnsiY2VfZmxhZ3MiOiI0IiwiY2VfdHlwZSI6IjgiLCJjZV92YWx1ZSI6IjMwIn19fX0sImNlX3ZlcnNpb25fbWFqb3IiOiI3IiwiY2VfdmVyc2lvbl9taW5vciI6IjEiLCJjZV92ZXJzaW9uX2J1aWxkIjoiMCJ9fX19"

arch=$(uname -m)
eraa_installer_url="http://repository.eset.com/v1/com/eset/apps/business/era/agent/v7/7.2.2233.0/agent_linux_i386.sh"
eraa_installer_checksum="591b4e374766019489c12222b298d25292fe2088"

if $(echo "$arch" | grep -E "^(x86_64|amd64)$" 2>&1 > /dev/null)
then
    eraa_installer_url="http://repository.eset.com/v1/com/eset/apps/business/era/agent/v7/7.2.2233.0/agent_linux_x86_64.sh"
    eraa_installer_checksum="d766d60393dad94791208e6515cc91feaa226eab"
fi

echo "ESET Management Agent live installer script. Copyright © 1992-2020 ESET, spol. s r.o. - All rights reserved."

if test ! -z $eraa_server_company_name
then
  echo " * CompanyName: $eraa_server_company_name"
fi
echo " * Hostname: $eraa_server_hostname"
echo " * Port: $eraa_server_port"
echo " * Installer: $eraa_installer_url"
echo

if test -z $eraa_installer_url
then
  echo "No installer available for '$arch' arhitecture."
  exit 1
fi

local_cert_path="$(mktemp -q -u)"
echo $eraa_peer_cert_b64 | base64 -d > "$local_cert_path" && echo "$local_cert_path" >> "$cleanup_file"

if test -n "$eraa_ca_cert_b64"
then
  local_ca_path="$(mktemp -q -u)"
  echo $eraa_ca_cert_b64 | base64 -d > "$local_ca_path" && echo "$local_ca_path" >> "$cleanup_file"
fi

local_installer="$(mktemp -q -u)"

eraa_http_proxy_value=""

echo "Downloading ESET Management Agent installer..."

if test -n "$eraa_http_proxy_value"
then
  export use_proxy=yes
  export http_proxy="$eraa_http_proxy_value"
  (wget --connect-timeout 300 --no-check-certificate -O "$local_installer" "$eraa_installer_url" || wget --connect-timeout 300 --no-proxy --no-check-certificate -O "$local_installer" "$eraa_installer_url" || curl --fail --connect-timeout 300 -k "$eraa_installer_url" > "$local_installer") && echo "$local_installer" >> "$cleanup_file"
else
  (wget --connect-timeout 300 --no-check-certificate -O "$local_installer" "$eraa_installer_url" || curl --fail --connect-timeout 300 -k "$eraa_installer_url" > "$local_installer") && echo "$local_installer" >> "$cleanup_file"
fi

if test ! -s "$local_installer"
then
   echo "Failed to download installer file"
   exit 2
fi

echo -n "Checking integrity of installer script " && echo "$eraa_installer_checksum  $local_installer" | sha1sum -c

chmod +x "$local_installer"

local_migration_list="$(mktemp -q -u)"
tee "$local_migration_list" 2>&1 > /dev/null << __LOCAL_MIGRATION_LIST__

__LOCAL_MIGRATION_LIST__
test $? = 0 && echo "$local_migration_list" >> "$cleanup_file"

for dir in /sys/class/net/*/
do
    if test -f "$dir/address"
    then
        grep -E '00:00:00:00:00:00' "$dir/address" > /dev/null || macs="$macs $(sed 's/\://g' "$dir/address" | awk '{print toupper($0)}')"
    fi
done

while read line
do
    if test -n "$macs" -a -n "$line"
    then
        mac=$(echo $line | awk '{print $1}')
        uuid=$(echo $line | awk '{print $2}')
        lsid=$(echo $line | awk '{print $3}')
        if $(echo "$macs" | grep "$mac" > /dev/null)
        then
            if test -n "$mac" -a -n "$uuid" -a -n "$lsid"
            then
                additional_params="--product-guid $uuid --log-sequence-id $lsid"
                break
            fi
        fi
    fi
done < "$local_migration_list"

command -v sudo > /dev/null && usesudo="sudo -E" || usesudo=""

export _ERAAGENT_PEER_CERT_PASSWORD="$eraa_peer_cert_pwd"

echo
echo Running installer script $local_installer
echo

$usesudo /bin/sh "$local_installer"\
   --skip-license \
   --hostname "$eraa_server_hostname"\
   --port "$eraa_server_port"\
   --cert-path "$local_cert_path"\
   --cert-password "env:_ERAAGENT_PEER_CERT_PASSWORD"\
   --cert-password-is-base64\
   --initial-static-group "$eraa_initial_sg_token"\
   \
   --enable-imp-program\
   $(test -n "$local_ca_path" && echo --cert-auth-path "$local_ca_path")\
   $(test -n "$eraa_product_uuid" && echo --product-guid "$eraa_product_uuid")\
   $(test -n "$eraa_policy_data" && echo --custom-policy "$eraa_policy_data")\
   $additional_params
